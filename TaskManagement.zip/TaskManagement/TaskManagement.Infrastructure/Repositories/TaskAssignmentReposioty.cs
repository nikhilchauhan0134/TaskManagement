﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagement.Domain.Entites;
using TaskManagement.Domain.Interfaces;
using TaskManagement.Infrastructure.DbContexts;
using TaskManagement.Shared.Helpers;

namespace TaskManagement.Infrastructure.Repositories
{
    public class TaskAssignmentReposioty : ITaskManagement
    {
        private readonly TaskManagerDbContext _dbContext;
        private readonly IUserService _userService;
        private readonly ITaskService _taskService;

        public TaskAssignmentReposioty(TaskManagerDbContext dbContext, IUserService userService, ITaskService taskService)
        {
            _dbContext = dbContext;
            _userService = userService;
            _taskService = taskService;
        }

        public async Task<IEnumerable<TaskAssignment>> GetAllAsync()
        {
            return await _dbContext.TaskAssignments
                .Include(t => t.AssignedToUser)
                .Include(t => t.Task)
                .ToListAsync();
        }

        public async Task<TaskAssignment> GetByIdAsync(int id)
        {
            return await _dbContext.TaskAssignments
                .Include(t => t.AssignedToUser)
                .Include(t => t.AssigneeId)
                .Include(t => t.Task)
                .FirstOrDefaultAsync(t => t.Id == id);
        }

        public async Task<User> GetUserByIdAsync(int userId)
        {
            return await _dbContext.Users.FindAsync(userId);
        }

        public async Task<TaskItem> GetTaskByIdAsync(int taskId)
        {
            return await _dbContext.Tasks.FindAsync(taskId);
        }

        public async Task<TaskAssignment> CreateAsync(TaskAssignment taskAssignment)
        {
            try
            {
                bool exists = await _dbContext.TaskAssignments
     .AnyAsync(ta => ta.TaskId == taskAssignment.TaskId && ta.AssigneeId == taskAssignment.AssigneeId && ta.AssignedToUserId == ta.AssignedToUserId);
                if (exists)
                {
                    throw new InvalidOperationException("Duplicate record found.");
                }
                _dbContext.TaskAssignments.Add(taskAssignment);
                await _dbContext.SaveChangesAsync();
            }
            catch (AppException ex) {

                throw new InvalidOperationException(ex.Message);
            }

            return taskAssignment;

        }
        public async Task UpdateAsync(TaskAssignment taskAssignment)
        {
            var existingTaskAssignment = await GetByIdAsync(taskAssignment.Id);
            if (existingTaskAssignment == null)
            {
                return; // Or throw an exception
            }

            // Check if the AssignedToUserId or IsDelegated properties have changed
            var isAssignedToUserIdChanged = taskAssignment.AssignedToUserId != existingTaskAssignment.AssignedToUserId;
            var isDelegatedChanged = taskAssignment.IsDelegated != existingTaskAssignment.IsDelegated;

            if (isAssignedToUserIdChanged)
            {
                existingTaskAssignment.AssignedToUserId = taskAssignment.AssignedToUserId;
                
            }

            if (isDelegatedChanged)
            {
                existingTaskAssignment.IsDelegated = taskAssignment.IsDelegated;
            }

            existingTaskAssignment.AssignedDate = taskAssignment.AssignedDate.ToUniversalTime();
            _dbContext.Entry(existingTaskAssignment).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
        }

        public async Task DeleteAsync(TaskAssignment taskAssi)
        {
            _dbContext.TaskAssignments.Remove(taskAssi);
            await _dbContext.SaveChangesAsync();
        }

        public async Task<IEnumerable<TaskAssignment>> GetAssignmentsByUserIdAsync(int userId)
        {
            return await _dbContext.TaskAssignments
                .Include(t => t.AssignedToUser)
                .Include(t => t.Task)
                .Where(t => t.AssignedToUserId == userId)
                .ToListAsync();
        }

        public async Task<IEnumerable<TaskAssignment>> GetAssignmentsByTaskIdAsync(int taskId)
        {
            return await _dbContext.TaskAssignments
                .Include(t => t.AssignedToUser)
                .Include(t => t.Task)
                .Where(t => t.TaskId == taskId)
                .ToListAsync();
        }

        public async Task<IEnumerable<TaskAssignment>> GetPendingAssignmentsByUserIdAsync(int userId)
        {
            var currentDate = DateTime.UtcNow.Date;
            return await _dbContext.TaskAssignments
                .Include(t => t.AssignedToUser)
                .Include(t => t.Task)
                .Where(t => t.AssignedToUserId == userId && t.Task.DueDate >= currentDate && t.Task.Status != TaskManagement.Domain.Entites.TaskStatus.Completed)
                .ToListAsync();
        }

        public async Task<IEnumerable<TaskAssignment>> GetOverdueAssignmentsByUserIdAsync(int userId)
        {
            var currentDate = DateTime.UtcNow.Date;
            return await _dbContext.TaskAssignments
                .Include(t => t.AssignedToUser)
                .Include(t => t.Task)
                .Where(t => t.AssignedToUserId == userId && t.Task.DueDate < currentDate && t.Task.Status != TaskManagement.Domain.Entites.TaskStatus.Completed)
                .ToListAsync();
        }
    }
}
