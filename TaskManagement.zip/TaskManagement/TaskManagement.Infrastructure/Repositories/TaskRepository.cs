﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagement.Domain.Entites;
using TaskManagement.Domain.Interfaces;
using TaskManagement.Infrastructure.DbContexts;

namespace TaskManagement.Infrastructure.Repositories
{
    public class TaskRepository : ITaskService
    {
        private readonly TaskManagerDbContext _dbContext;

        public TaskRepository(TaskManagerDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IEnumerable<TaskItem>> GetAllAsync()
        {
            return await _dbContext.Tasks.ToListAsync();
        }

        public async Task<TaskItem> GetByIdAsync(int id)
        {
            return await _dbContext.Tasks.FirstOrDefaultAsync(t => t.Id == id);
        }

        public async Task CreateAsync(TaskItem taskItem)
        {

            try
            {
                _dbContext.Tasks.Add(taskItem);
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw ex;
            }
            
        }

        public async Task UpdateAsync(TaskItem taskItem)
        {
            try
            {
                var existingTask = await _dbContext.Tasks.FindAsync(taskItem.Id);

                if (existingTask == null)
                {
                    throw new ArgumentException("Task not found");
                }

                existingTask.Title = taskItem.Title;
                existingTask.Description = taskItem.Description;
                existingTask.DueDate = taskItem.DueDate;
                existingTask.Priority = taskItem.Priority;
                existingTask.Status = taskItem.Status;

                await _dbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception or inspect its details for debugging purposes
                throw new ArgumentException("Error updating task: " + ex.Message);
            }
        }

        public async Task DeleteAsync(TaskItem taskItem)
        {
            _dbContext.Tasks.Remove(taskItem);
            await _dbContext.SaveChangesAsync();
        }

        public async Task TaskUpdateByEmployee(TaskItem taskItem, int employeeUserId)
        {
            try
            {
               
                var existingTask = await (from ti in _dbContext.Tasks
                                          join ta in _dbContext.TaskAssignments on ti.Id equals ta.TaskId
                                          where ti.Id == taskItem.Id && ta.AssignedToUserId == employeeUserId
                                          select ti).FirstOrDefaultAsync();

                if (existingTask == null)
                {
                    throw new ArgumentException("Task not found or the user is not assigned to this task.");
                }
                existingTask.Status = taskItem.Status;
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception or inspect its details for debugging purposes
                throw new ArgumentException("Error updating task: " + ex.Message);
            }
        }

        public async Task<IEnumerable<TaskReport>> TaskReports()
        {
            var taskReports = await (from t in _dbContext.Tasks
                                     join ta in _dbContext.TaskAssignments on t.Id equals ta.TaskId into taGroup
                                     from ta in taGroup.DefaultIfEmpty() // Left join
                                     join u in _dbContext.Users on ta.AssignedToUserId equals u.Id into uGroup
                                     from u in uGroup.DefaultIfEmpty() // Left join
                                     join ua in _dbContext.Users on ta.AssigneeId equals ua.Id into uaGroup
                                     from ua in uaGroup.DefaultIfEmpty() // Left join
                                     select new TaskReport
                                     {
                                         TaskId = t.Id,
                                         Title = t.Title,
                                         Description = t.Description,
                                         DueDate = t.DueDate,
                                         Priority = (t.Priority == TaskPriority.Low) ? "Pending" :
                                            (t.Priority == TaskPriority.Medium) ? "InProgress" :
                                            (t.Priority == TaskPriority.High) ? "Completed" :
                                            "Unknown",
                                         Status = (t.Status == TaskManagement.Domain.Entites.TaskStatus.Pending) ? "Pending" :
                                          (t.Status == TaskManagement.Domain.Entites.TaskStatus.InProgress) ? "InProgress" :
                                          (t.Status == TaskManagement.Domain.Entites.TaskStatus.Completed) ? "Completed" :
                                          (t.Status == TaskManagement.Domain.Entites.TaskStatus.Overdue) ? "Overdue" :
                                          "Unknown",
                                       
                                         AssignedToEmail = u != null ? u.Email : "Not assigned",
                                         AssignedEmployee = u != null ? u.Username : "Not assigned",
                                         AssignedManager = ua != null ? ua.Username : "Not assigned"
                                     }).ToListAsync();

            return taskReports;
        }

    }
}
