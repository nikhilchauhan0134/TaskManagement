﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagement.Domain.Entites;

namespace TaskManagement.Domain.Interfaces
{
    public interface IUserService
    {
        Task<User> AuthenticateAsync(string username, string password);
        Task<User> CreateAsync(User user, string password);
        Task<User> GetByIdAsync(int id);

    }
}
