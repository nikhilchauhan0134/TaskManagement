﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskManagement.Domain.Entites
{
    [Table("TaskItem")]
    public class TaskItem
    {
        [Key]
        public int Id { get; set; }
        [Column("Title")]
        public string Title { get; set; }
        [Column("Description")]
        public string Description { get; set; }
        [Column("DueDate")]
        public DateTime DueDate { get; set; }
        [Column("Priority")]
        public TaskPriority Priority { get; set; }
        [Column("Status")]
        public TaskStatus Status { get; set; }
    }

    public enum TaskPriority
    {
        Low=1,
        Medium=2,
        High=3
    }

    public enum TaskStatus
    {
        Pending=1,
        InProgress=2,
        Completed=3,
        Overdue=4
    }
}
