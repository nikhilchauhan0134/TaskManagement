﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TaskManagement.Domain.Entites;
using TaskManagement.Domain.Interfaces;
using TaskManagement.DTOs;

namespace TaskManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TasksController : ControllerBase
    {
        private readonly ITaskService _taskService;

        public TasksController(ITaskService taskService)
        {
            _taskService = taskService;
        }

        [HttpGet("Gettasks")]
        public async Task<ActionResult<IEnumerable<TaskItem>>> GetAll()
        {
            try
            {
                var tasks = await _taskService.GetAllAsync();
                return Ok(tasks);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("Getbyid")]
        public async Task<IActionResult> GetById([FromBody] GetByIdDto getByIdDto)
        {
            var task = await _taskService.GetByIdAsync(getByIdDto.Id);

            if (task == null)
            {
                return NotFound();
            }

            return Ok(task);
        }

        [HttpPost("Createtask")]
        public async Task<ActionResult<TaskItem>> CreateTask(TaskItem taskItem)
        {
            try
            {
                await _taskService.CreateAsync(taskItem);
                return CreatedAtAction(nameof(GetById), new { id = taskItem.Id }, taskItem);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("Updatetask")]
        public async Task<IActionResult> Update([FromBody] UpdateTaskDTO updateTaskDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var taskItem = new TaskItem
            {
                Id = updateTaskDto.Id,
                Title = updateTaskDto.Title,
                Description = updateTaskDto.Description,
                DueDate = updateTaskDto.DueDate
            };

            try
            {
                await _taskService.UpdateAsync(taskItem);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("Deletetask")]
        public async Task<IActionResult> Delete([FromBody] DeleteTaskDTO deleteDto)
        {
            try
            {
                var task = await _taskService.GetByIdAsync(deleteDto.Id);
                if (task == null)
                {
                    return NotFound();
                }
                await _taskService.DeleteAsync(task);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("TaskUpdateByEmployee")]
        public async Task<IActionResult> TaskUpdateByEmployee([FromBody] EmployeeDto employeeDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var taskItem = new TaskItem
            {
                Id = employeeDto.TaskId,
                Status = employeeDto.Status,
            };
            try
            {
                await _taskService.TaskUpdateByEmployee(taskItem, employeeDto.EmployeeUserId);
                return Ok(new { Message = "Task Status Succesfully" });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("TaskReportsAccessByAdmin")]
        public async Task<IActionResult> TaskReports()
        {
            
            try
            {
               var task= await _taskService.TaskReports();
                return Ok(task);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


    }
}
