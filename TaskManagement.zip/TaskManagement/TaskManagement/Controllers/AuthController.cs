﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TaskManagement.Domain.Entites;
using TaskManagement.Domain.Interfaces;
using TaskManagement.DTOs;
using TaskManagement.Shared.Helpers;

namespace TaskManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {

        private readonly IUserService _userService;
        private readonly IJwtService _jwtService;

        public AuthController(IUserService userService, IJwtService jwtService)
        {
            _userService = userService;
            _jwtService = jwtService;
        }
        [HttpPost("login")]
        public async Task<IActionResult> Authenticate([FromBody] UserAuthenticateDto userDto)
        {
            var user = await _userService.AuthenticateAsync(userDto.Username, userDto.Password);

            if (user == null)
                return BadRequest(new { message = "Username or password is incorrect" });

            string token = await _jwtService.GenerateTokenAsync(user);
            return Ok(new { Token = token,Message="Login Successfully" });
        }


        [HttpPost("Registration")]
        public async Task<IActionResult> Create([FromBody] UserCreateDto userDto)
        {
            // map dto to entity
            var user = new User
            {
                Username = userDto.Username,
                Email = userDto.Email,
                Role = userDto.Role
            };

            try
            {
                // create user
                await _userService.CreateAsync(user, userDto.Password);
                return Ok();
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
