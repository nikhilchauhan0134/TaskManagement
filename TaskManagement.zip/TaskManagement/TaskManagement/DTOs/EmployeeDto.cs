﻿using TaskManagement.Domain.Entites;

namespace TaskManagement.DTOs
{

    public class EmployeeDto
    {
        public int TaskId { get; set; }
        public int EmployeeUserId { get; set; }
        public TaskManagement.Domain.Entites.TaskStatus Status { get; set; }
    }
}
