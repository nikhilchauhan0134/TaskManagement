﻿namespace TaskManagement.Shared
{
    public class Class1
    {

    }
}
